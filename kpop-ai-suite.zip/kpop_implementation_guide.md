
# K-pop Group Name Generator - Implementation Guide

## Files Structure:
```
kpop-tools/
├── index.html
├── css/
│   └── styles.css
├── js/
│   ├── main.js
│   ├── gemini-api.js
│   └── name-generator.js
├── assets/
│   ├── images/
│   └── icons/
└── README.md
```

## Step 1: HTML Structure (index.html)
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>K-pop AI Tools Suite</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <header>
        <h1>🎵 K-pop AI Tools Suite</h1>
        <nav>
            <button class="tool-btn active" data-tool="name-generator">Name Generator</button>
            <button class="tool-btn" data-tool="bias-chat">Bias Chat</button>
            <!-- Add more tool buttons -->
        </nav>
    </header>

    <main>
        <div id="name-generator" class="tool-section active">
            <h2>K-pop Group Name Generator</h2>
            <div class="input-section">
                <label for="group-type">Group Type:</label>
                <select id="group-type">
                    <option value="boy-group">Boy Group</option>
                    <option value="girl-group">Girl Group</option>
                    <option value="mixed">Mixed Group</option>
                </select>

                <label for="theme">Theme:</label>
                <select id="theme">
                    <option value="cute">Cute</option>
                    <option value="powerful">Powerful</option>
                    <option value="mysterious">Mysterious</option>
                    <option value="retro">Retro</option>
                </select>

                <button id="generate-name" class="generate-btn">Generate Name!</button>
            </div>

            <div id="result-section">
                <h3>Your K-pop Group Name:</h3>
                <div id="generated-name"></div>
                <div id="name-meaning"></div>
            </div>
        </div>
    </main>

    <script src="js/main.js"></script>
</body>
</html>
```

## Step 2: JavaScript Implementation (js/name-generator.js)
```javascript
// Configuration
const GEMINI_API_KEY = 'YOUR_GEMINI_API_KEY'; // Get from Google AI Studio
const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent';

class KpopNameGenerator {
    constructor() {
        this.initializeEventListeners();
    }

    initializeEventListeners() {
        const generateBtn = document.getElementById('generate-name');
        generateBtn.addEventListener('click', () => this.generateName());
    }

    async generateName() {
        const groupType = document.getElementById('group-type').value;
        const theme = document.getElementById('theme').value;

        const prompt = this.createPrompt(groupType, theme);

        try {
            const result = await this.callGeminiAPI(prompt);
            this.displayResult(result);
        } catch (error) {
            console.error('Error generating name:', error);
            this.displayError('Failed to generate name. Please try again.');
        }
    }

    createPrompt(groupType, theme) {
        return `Generate a creative K-pop group name for a ${groupType} with a ${theme} concept. 
                Also provide a brief explanation of the name's meaning and how it fits the concept.
                Format the response as JSON with 'name' and 'meaning' fields.
                Make it sound authentic and appealing to K-pop fans.`;
    }

    async callGeminiAPI(prompt) {
        const response = await fetch(GEMINI_API_URL + '?key=' + GEMINI_API_KEY, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                contents: [{
                    parts: [{
                        text: prompt
                    }]
                }]
            })
        });

        if (!response.ok) {
            throw new Error('API request failed');
        }

        const data = await response.json();
        return data.candidates[0].content.parts[0].text;
    }

    displayResult(result) {
        try {
            const parsed = JSON.parse(result);
            document.getElementById('generated-name').textContent = parsed.name;
            document.getElementById('name-meaning').textContent = parsed.meaning;
        } catch (e) {
            // Fallback if JSON parsing fails
            document.getElementById('generated-name').textContent = result.split('\n')[0];
            document.getElementById('name-meaning').textContent = 'A unique K-pop group name generated just for you!';
        }
    }

    displayError(message) {
        document.getElementById('generated-name').textContent = 'Error';
        document.getElementById('name-meaning').textContent = message;
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new KpopNameGenerator();
});
```

## Step 3: CSS Styling (css/styles.css)
```css
/* K-pop inspired styling */
body {
    font-family: 'Arial', sans-serif;
    background: linear-gradient(135deg, #ff6b6b, #4ecdc4, #45b7d1);
    margin: 0;
    padding: 20px;
    min-height: 100vh;
}

header {
    text-align: center;
    margin-bottom: 30px;
}

h1 {
    color: white;
    font-size: 2.5rem;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    margin-bottom: 20px;
}

nav {
    display: flex;
    justify-content: center;
    gap: 10px;
    flex-wrap: wrap;
}

.tool-btn {
    background: white;
    border: none;
    padding: 10px 20px;
    border-radius: 25px;
    cursor: pointer;
    font-weight: bold;
    transition: all 0.3s ease;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.tool-btn:hover, .tool-btn.active {
    background: #ff6b6b;
    color: white;
    transform: translateY(-2px);
}

.tool-section {
    background: white;
    border-radius: 20px;
    padding: 30px;
    margin: 20px auto;
    max-width: 600px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
    display: none;
}

.tool-section.active {
    display: block;
}

.input-section {
    margin-bottom: 30px;
}

label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
    color: #333;
}

select {
    width: 100%;
    padding: 12px;
    margin-bottom: 15px;
    border: 2px solid #ddd;
    border-radius: 10px;
    font-size: 16px;
    background: white;
}

.generate-btn {
    background: linear-gradient(45deg, #ff6b6b, #4ecdc4);
    color: white;
    border: none;
    padding: 15px 30px;
    font-size: 18px;
    border-radius: 25px;
    cursor: pointer;
    width: 100%;
    font-weight: bold;
    transition: transform 0.3s ease;
}

.generate-btn:hover {
    transform: scale(1.05);
}

#result-section {
    text-align: center;
    padding: 20px;
    background: linear-gradient(135deg, #ffeaa7, #fab1a0);
    border-radius: 15px;
    margin-top: 20px;
}

#generated-name {
    font-size: 2rem;
    font-weight: bold;
    color: #2d3436;
    margin-bottom: 10px;
}

#name-meaning {
    font-size: 1.1rem;
    color: #636e72;
    line-height: 1.5;
}

/* Responsive design */
@media (max-width: 768px) {
    body {
        padding: 10px;
    }

    h1 {
        font-size: 2rem;
    }

    .tool-section {
        margin: 10px;
        padding: 20px;
    }
}
```

## Step 4: Deployment to GitHub Pages

1. Create a new repository on GitHub
2. Upload all files to the repository
3. Go to Settings > Pages
4. Select source as "Deploy from a branch"
5. Choose "main" branch
6. Your site will be available at: https://username.github.io/repository-name

## Step 5: Add Custom Domain (Optional)

1. Register free domain at Freenom.com (.tk, .ml, .ga)
2. Add CNAME record pointing to username.github.io
3. Add custom domain in GitHub Pages settings
4. Enable HTTPS

## API Rate Limiting Considerations:

- Google Gemini: 15 requests/minute, 250K tokens/day
- Implement client-side caching to reduce API calls
- Add loading states and error handling
- Consider rate limiting user requests

## Security Notes:

- Never expose API keys in client-side code for production
- Use environment variables or server-side proxy
- Implement proper error handling
- Add input validation and sanitization
